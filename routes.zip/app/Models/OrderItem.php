<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    protected $fillable = [
        'order_id',
        'product_id',
        'product_variant_id',
        'qty',
        'price',
        'total',
    ];

    // 🔗 Order
    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    // 🔗 Product
    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    // 🔗 Product Variant ✅ (THIS FIXES THE ERROR)
    public function productVariant()
    {
        return $this->belongsTo(ProductVariant::class, 'product_variant_id');
    }
}
