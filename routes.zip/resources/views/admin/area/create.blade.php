@extends('layouts.admin.create_app')

@section('content')
    <div class="row g-3">
        <div class="col-sm-6">
            <label for="region_id" class="form-label"><b>Region <span class="text-danger">*</span></b></label>
            <select name="region_id" id="region_id" class="form-select select" data-placeholder="Select Region" required>
                <option value=""></option>
                @foreach ($regions as $item)
                    <option value="{{ $item->id }}" {{ old('region_id') == $item->id ? 'selected' : '' }}>
                        {{ $item->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-sm-6">
            <label for="code" class="form-label"><b>Code</b></label>
            <input type="text" class="form-control" id="code" name="code" value="{{ old('code') }}"
                placeholder="Code">
        </div>
        <div class="col-sm-6">
            <label for="name" class="form-label"><b>Name <span class="text-danger">*</span></b></label>
            <input type="text" class="form-control" id="name" name="name" value="{{ old('name') }}"
                placeholder="Name" required>
        </div>
        <div class="col-sm-6">
            <label for="incharge" class="form-label"><b>Incharge</b></label>
            <input type="text" class="form-control" id="incharge" name="incharge" value="{{ old('incharge') }}"
                placeholder="Incharge">
        </div>
        <div class="col-sm-6">
            <label for="phone" class="form-label"><b>Phone</b></label>
            <input type="text" class="form-control" id="phone" name="phone" value="{{ old('phone') }}"
                placeholder="Phone">
        </div>
        <div class="col-sm-6">
            <label for="email" class="form-label"><b>Email</b></label>
            <input type="email" class="form-control" id="email" name="email" value="{{ old('email') }}"
                placeholder="Email">
        </div>
        <div class="col-sm-6">
            <label for="address" class="form-label"><b>Address</b></label>
            <input type="text" class="form-control" id="address" name="address" value="{{ old('address') }}"
                placeholder="Address">
        </div>
    </div>
@endsection
